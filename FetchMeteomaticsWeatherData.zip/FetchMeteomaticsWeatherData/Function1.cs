using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Azure.Storage.Blobs;
using System.IO;

namespace WeatherFunctionApp
{
    public static class MeteomaticsFunction
    {
        private static readonly HttpClient httpClient = new HttpClient();
        private static readonly string storageConnectionString = Environment.GetEnvironmentVariable("AZURE_STORAGE_CONNECTION_STRING");
        private static readonly BlobServiceClient blobServiceClient = new BlobServiceClient(storageConnectionString);
        private static readonly BlobContainerClient containerClient = blobServiceClient.GetBlobContainerClient("weatherdata");

        [FunctionName("FetchMeteomaticsWeatherData")]
        public static async Task Run(
            [TimerTrigger("0 0 * * * *")] TimerInfo myTimer, // Adjust the schedule as needed
            ILogger log)
        {
            log.LogInformation($"C# Timer trigger function executed at: {DateTime.Now}");

            string meteomaticsUsername = Environment.GetEnvironmentVariable("METEOMATICS_USERNAME");
            string meteomaticsPassword = Environment.GetEnvironmentVariable("METEOMATICS_PASSWORD");
            string apiUrl = ConstructMeteomaticsApiUrl();

            try
            {
                // Fetch Meteomatics access token
                string accessToken = await GetMeteomaticsAccessToken(meteomaticsUsername, meteomaticsPassword);

                // Add the access token to the API URL
                apiUrl += $"?access_token={accessToken}";

                HttpResponseMessage response = await httpClient.GetAsync(apiUrl);
                if (response.IsSuccessStatusCode)
                {
                    string content = await response.Content.ReadAsStringAsync();
                    log.LogInformation($"Received Meteomatics weather data: {content}");

                    // Save data to Azure Blob Storage
                    string blobName = "latestMeteomaticsWeatherData.json"; // Fixed name for the blob
                    BlobClient blobClient = containerClient.GetBlobClient(blobName);

                    using (var stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(content)))
                    {
                        await blobClient.UploadAsync(stream, overwrite: true);
                        log.LogInformation($"Meteomatics weather data uploaded to Blob storage as blob: {blobName}");
                    }
                }
                else
                {
                    log.LogError($"Failed to fetch Meteomatics weather data. Status Code: {response.StatusCode}");
                }
            }
            catch (Exception ex)
            {
                log.LogError($"Error fetching Meteomatics weather data: {ex.Message}");
            }
        }

        private static async Task<string> GetMeteomaticsAccessToken(string username, string password)
        {
            using var client = new HttpClient();
            var authHeader = Convert.ToBase64String(Encoding.ASCII.GetBytes($"{username}:{password}"));
            client.DefaultRequestHeaders.Add("Authorization", $"Basic {authHeader}");

            var response = await client.GetAsync("https://login.meteomatics.com/api/v1/token");
            response.EnsureSuccessStatusCode();

            var tokenResponse = await response.Content.ReadAsStringAsync();
            return tokenResponse;
        }

        private static string ConstructMeteomaticsApiUrl()
        {
            // Calculate the "to" date as 7 days from now
            var toDate = DateTime.UtcNow.Add(TimeSpan.FromDays(7)).ToString("yyyy-MM-ddTHH:mm:ssZ");

            // Construct the Meteomatics API URL
            return $"https://api.meteomatics.com/{DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ")}--{toDate}:PT1H/wind_speed_10m:ms,wind_dir_10m:d,wind_gusts_10m_1h:ms,precip_1h:mm/58.81231852222533,5.546945324943648/json";
        }
    }
}
